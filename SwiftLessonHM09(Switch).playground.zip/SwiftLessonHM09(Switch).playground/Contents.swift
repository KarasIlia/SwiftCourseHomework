//:Swift Lesson 09 | Homework
//:Part 1
var string = "A 5witch statement c0nsiders a va1ue and c0mpare5 it against s3v3ra1 po55ible matching patterns. It then execute5 an appropriate block of code, ba5ed 0n the fir5t pattern that matches succe55fu11y. A switch statement provides an a1ternative t0 the if statement for responding to mu1tip1e potential states."

var infoTuple = (vowels: 0, consonants: 0, digits: 0, specSymbols: 0, gaps: 0)

let vowelsString = "bcdfghjklmnpqrstvwxyz"
let consonantsString = "aeiou"
let digitsString = "0123456789"

for char in string.lowercased() {
    
    switch char {
        
    case _ where vowelsString.contains(char):
        infoTuple.vowels += 1
        
    case _ where consonantsString.contains(char):
        infoTuple.consonants += 1
        
    case _ where digitsString.contains(char):
        infoTuple.digits += 1
        
    case " " :
        infoTuple.gaps += 1
        
    default:
        infoTuple.specSymbols += 1
    }
}

let sumOfChars = infoTuple.vowels + infoTuple.consonants + infoTuple.digits + infoTuple.gaps + infoTuple.specSymbols
    
print("""
    Total number of...
    
    ...vowels in a string     : \(infoTuple.vowels)
                                +
    ...consonants in a string : \(infoTuple.consonants)
                                +
    ...digits in a string     : \(infoTuple.digits)
                                +
    ...gaps in a string       : \(infoTuple.gaps)
                                +
    ...special symbols        : \(infoTuple.specSymbols)
                                =
    ...characters             : \(sumOfChars)
    -------------------------------
    """)
//: Part 2
let age = 66

switch age {
    
case 0...6:
    print("Kindergarten")

case 7...17:
    print("School")

case 17...23:
    print("University")

case 23...65:
    print("Job")

case _ where age < 0:
    print("Wrong data")

default:
    print("Pension")
}

print("-------------------------------")
//: Part 3
let student = (name: "Иван", lastName: "Иванов", midName: "Иванович")

switch student {
    
case (let name, _, _) where name.hasPrefix("А") || name.hasPrefix("О"):
    print("Привет, \(student.name)!")

case (_, let midName, _) where midName.hasPrefix("В") || midName.hasPrefix("Д"):
    print("Здравствуйте, \(student.name) \(student.midName)!")

case (_, _, let lastName) where lastName.hasPrefix("Е") || lastName.hasPrefix("З"):
        print("Здорово, \(student.lastName)!")

default:
    print("Вас зовут \(student.lastName) \(student.name) \(student.midName)?")
}

print("-------------------------------")
//:Part 4
let xAxis = ("abcdefghij")
let yAxis = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

var oneCellShip   = [1:(x:"a", y:1)]
var twoCellShip   = [1:(x:"e", y:5), 2:(x:"f", y:5)]
var threeCellShip = [1:(x:"g", y:4), 2:(x:"g", y:5), 3:(x:"g", y:6)]

var arrayOfShips = [oneCellShip.values, twoCellShip.values, threeCellShip.values]

// Setted ships data check
for ship in arrayOfShips{

    for cell in ship {
        
        let charX = Character(cell.x)

        if !(xAxis.contains(charX) && yAxis.contains(cell.y)) {
            print("---Error: setted data is wrong!---")
        }
    }
}

var hitList = [(x:"g", y:5), (x:"a", y:1), (x:"f", y:6)]

var hitCounter = 1

for hitPoint in hitList {
    
    print("Hit #\(hitCounter):")
    
    hitCounter += 1
    
    switch hitPoint {
        
    case _ where hitPoint.x == oneCellShip[1]!.x && hitPoint.y == oneCellShip[1]!.y:
            
        print("One-cell ship is killed!")
        
    case _ where ((hitPoint.x == twoCellShip[1]!.x && hitPoint.y == twoCellShip[1]!.y) ||
                  (hitPoint.x == twoCellShip[2]!.x && hitPoint.y == twoCellShip[2]!.y)):
            
        print("Two-cell ship is wounded.")
        
    case _ where ((hitPoint.x == threeCellShip[1]!.x && hitPoint.y == threeCellShip[1]!.y) ||
                  (hitPoint.x == threeCellShip[2]!.x && hitPoint.y == threeCellShip[2]!.y) ||
                  (hitPoint.x == threeCellShip[3]!.x && hitPoint.y == threeCellShip[3]!.y)):
            
        print("Three-cell ship is wounded.")
        
    default:
        print("Miss")
    }
}
//:Alternative Part 4
// В данном примере корабли представляются в виде прямоугольников, где
var oneCellShip2   = (x:0, y:0, h:1, w:1) // x, y - координаты начала прямоугольника корабля
var twoCellShip2   = (x:5, y:5, h:2, w:1) // h, w - высота и ширина прямоугольника корабля, соответственно
var threeCellShip2 = (x:7, y:4, h:1, w:3)

let shipsArray = [oneCellShip2, twoCellShip2, threeCellShip2]

for ship in shipsArray {
    if (ship.x + ship.h > 10) || (ship.y + ship.h > 10) {
        print("Wrong coordinates of the ship")
    }
}

let hit = (x:8, y:7)

switch hit {
case (let x, let y) where (x < 1 || x > 10) || (y < 1 || y > 10):
    print("Hit outside of range")
    
case (let x, let y) where (x <= oneCellShip2.x + oneCellShip2.h && x > oneCellShip2.x) &&
                          (y <= oneCellShip2.y + oneCellShip2.w && y > oneCellShip2.y):
    print("Target killed")
    
case (let x, let y) where (x <= twoCellShip2.x + twoCellShip2.h && x > twoCellShip2.x) &&
                          (y <= twoCellShip2.y + twoCellShip2.w && y > twoCellShip2.y):
    print("Ship 2 wounded")
    
case (let x, let y) where (x <= threeCellShip2.x + threeCellShip2.h && x > threeCellShip2.x) &&
                          (y <= threeCellShip2.y + threeCellShip2.w && y > threeCellShip2.y):
    print("Ship 3 wounded")
    
default:
    print("miss")
}
