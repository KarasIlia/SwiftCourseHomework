//: Swift Lesson 17 | Homework
import UIKit
// Easy level
print("---------------EZ PZ LS--------------")
enum CellColor: String {
    case White = "White"
    case Black = "Black"
}

struct Chessboard {
    
    private func colorOfCell(column: String, row: Int) -> CellColor? {
        
        let dict = ["a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8]
        
        if !dict.keys.contains(column.lowercased()) || !dict.values.contains(row) {
            return nil
        }
        
        if (dict[column.lowercased()]! + row) % 2 != 0 {
            return .White
        } else {
            return .Black
        }
    }
    
    subscript (column: String, row: Int) -> CellColor? {
        return colorOfCell(column: column, row: row)
    }
}

var desk = Chessboard()

desk["c",5]
desk["a",0]
desk["b",5]
//: Middle level
print("---------------MEDUIM---------------")
enum CellView: String {
    case Empty = "⬜"
    case Cross = "❌"
    case Circle = "⭕"
}

class Field {
    
    var fieldDict = [Int:[Int:CellView]]()
    
    var turnCash: CellView? = nil
    
    init() {
        for i in 1...3 {
            fieldDict[i] = [:]
        }
    }
    
    subscript (column: Int, row: Int) -> CellView? {
        
        get {
            if let cell = fieldDict[column]![row] {
                return cell
            }
            return nil
        }
        
        set {
            switch (column, row){
                
            case _ where self.turnCash == newValue: // Whose turn?
                print("Not your turn!")
                
            case _ where (1...3).contains(column) && (1...3).contains(row) && self[column,row] == nil:
                
                fieldDict[column]![row] = newValue!
                
                turnCash = newValue
                
                printField()
                
                checkWin()

            default:
                print("Wrong coordinates (\(column),\(row))!")

            }
        }
    }
    
    func checkWin() {
        
        let win = "Congratulations! \(turnCash!.rawValue) - player wins."
        
        if  (self[1,1] == self[2,2]) && (self[1,1] == self[3,3]) && (self[1,1] != nil) ||
            (self[1,3] == self[2,2]) && (self[1,3] == self[3,1]) && (self[1,3] != nil) {
            
            print(win)
        } else {
        
            for i in 1...3{
                
                if  (self[i,1] == self[i,2]) && (self[i,1] == self[1,3]) && (self[i,1] != nil) ||
                    (self[1,i] == self[2,i]) && (self[1,i] == self[3,i]) && (self[1,i] != nil) {
                
                print(win)
                }
            }
        }
    }
    
    func printField() {
        
        print("   1  2  3")
        
        for i in 1...3 {
            
            var line = "\(i)"
            
            for j in 1...3 {
                
                if let view = self[i,j] {
                    line.append(" " + view.rawValue)
                } else {
                    line.append(" " + CellView.Empty.rawValue)
                }
            }
            
            print(line)
        }
    }
    
    func clearField() {
        
        for i in 1...3 {
            fieldDict[i] = [:]
        }
        
        self.turnCash = nil
    }
}

var field = Field()

field[1,1]
field[1,1] = .Cross
field[2,2] = .Circle
field[1,4] = .Cross // Wrong coordinates
field[1,2] = .Cross
field[1,3] = .Cross // Not your turn
field[3,3] = .Circle
field[1,3] = .Cross

field.clearField()
field.printField()

field[2,2] = .Cross
//: Hard level
print("--------------HARD--------------")
//: Part 1
class Ship {
    
    var heigth: Int
    var width: Int
    
    var ship = [(Int,Int)]()
    
    init(width: Int, height: Int) {
        self.heigth = height
        self.width = width
        
        for i in 1...width {
            for j in 1...height {
                let cell = (i,j)
                ship.append(cell)
            }
        }

    }
    
    subscript (column: Int, row: Int) -> Bool {
        
        get {
            if self.width == column && self.heigth == row {
                return true
            }
            return false
        }
    }
    
    func shotTo(_ column: Int, _ andRow: Int) {
        
        if let index = ship.firstIndex(where: { (item) -> Bool in
            item == (column, andRow) }) {
            
            ship.remove(at: index)
            
            print("Ship wounded. Health left: \(ship.count)")
            
            ship.isEmpty ? print("Ship killed") : print("Health left: \(ship.count)")
        } else {
            print("Miss")
        }
    }
}


var ship1 = Ship(width: 4, height: 1)

print(ship1.ship)

ship1.shotTo(2,1)
print(ship1.ship)

ship1.shotTo(1,1)
print(ship1.ship)

ship1.shotTo(3,1)
ship1.shotTo(5,1)
print(ship1.ship)

ship1.shotTo(4,1)

//enum SeaViews: String {
//    case Sea = "🌊"
//    case Boom = "🎇"
//    case Ship = "⬛"
//}
//
//class SeaField {
//
//    let dict = ["a": 1, "b": 2, "c": 3, "d": 4, "e": 5, "f": 6, "g": 7, "h": 8, "i": 9, "j": 10]
//
//    var field = [Int:[Int:SeaViews]]()
//
//    init() {
//        for i in 1...10 {
//            field[i] = [:]
//        }
//    }
//
//    subscript (column: Int, row: Int) -> String? {
//
//        get {
//            if let cell = self.field[column]![row] {
//                return cell.rawValue
//            }
//            return nil
//        }
//    }
//
//    func set(ship: Ship) {
//
//    }
//
//    func makeShot(column: String, row: Int) {
//
//    }
//}

