//: Swift Lesson 23 | Homework
//: Part 1 & 2
print("--------TASK I & II--------")
class Animal {
    func says() {
    }
}

class Human {
    
    var num: String = ""
    var father: Man?
    var mother: Woman?
    
    var pet: [Animal]?
    
    var brothers: [Man]? {
        
        var tempa = [Man]()
        
        for i in man {
            
            if (i.father === self.father) && (i.mother === self.mother) && (i !== self) {
                tempa.append(i)
            }
        }
        return tempa
    }
    
    var sisters: [Woman]? {
        
        var tempa = [Woman]()
        
        for i in woman {
            
            if (i.father === self.father) && (i.mother === self.mother) && (i !== self) {
                tempa.append(i)
            }
        }
        return tempa
    }
}

class Man: Human {
    
    func moveSofa() {
        print("Moving the sofa")
    }
}

class Woman: Human {
    
    func command() {
        print("Please move the sofa")
    }
}

var woman = [Woman]()
var man = [Man]()

for i in 1...16 {
    let m = Man()
    let w = Woman()
    m.num = "man " + String(i - 1)
    w.num = "woman " + String(i - 1)
    man.append(m)
    woman.append(w)
}

// n - generation parents
man[0].father = man[1]
man[0].mother = woman[1]
man[14].father = man[0].father
man[14].mother = man[0].mother
woman[0].father = man[0].father
woman[0].mother = man[0].mother

// n-1 - generation mom parents
woman[1].father = man[3] // Dad
woman[1].mother = woman[3] // Mom

man[4].father = woman[1].father // Dad
man[4].mother = woman[1].mother // Mom

woman[6].father = woman[1].father // Dad
woman[6].mother = woman[1].mother // Mom

// n-1 - generation dad parents (2 sis. & bro)
man[1].father = man[2] // Dad
man[1].mother = woman[2] // Mom

woman[4].father = man[1].father // Dad
woman[4].mother = man[1].mother // Mom

woman[5].father = man[1].father // Dad
woman[5].mother = man[1].mother // Mom

// n - gen man
man[5].father = man[13]
man[5].mother = woman[4]

// n - gen (sis. & 2 bros.)
woman[7].father = man[11]
woman[7].mother = woman[5]

man[6].father = woman[7].father
man[6].mother = woman[7].mother

man[7].father = woman[7].father
man[7].mother = woman[7].mother

// n - gen (2 sis.)
woman[8].father = man[4]
woman[8].mother = woman[14]

woman[9].father = woman[8].father
woman[9].mother = woman[8].mother

// n-1 - gen
man[13].father = man[8]
man[13].mother = woman[10]

man[11].father = man[9]
man[11].mother = woman[11]

man[12].father = man[11]
man[12].mother = woman[13]

woman[14].father = man[10]
woman[14].mother = woman[12]

man[15].father = man[12]
man[15].mother = woman[6]


func findRelatives(ofHuman: Human) {
    
    var grandmas = 0, grandpas = 0, cousinBr = 0, cousinSis = 0
    
    var unclesCash = [String?:String?]()
    
    var auntsCash = [String?:String?]()
    
    func check(_ human: Human) -> () {
        ((human as? Man) != nil) ? (cousinBr += 1) : (cousinSis += 1)
        
        unclesCash[human.father?.num] = ""
        auntsCash[human.mother?.num] = ""
    }
    
    for human in (man + woman) {
        
        if human !== ofHuman.father && human !== ofHuman.mother && human !== ofHuman {
            
            switch human {
                // Cousins, aunts search
            case _ where ((ofHuman.father?.sisters?.contains(where: { (h) -> Bool in
                if h === human.mother {
                    return true
                }
                return false
            }))!):
                check(human)
                
                // Cousins, uncle search
            case _ where ((ofHuman.father?.brothers?.contains(where: { (h) -> Bool in
                if h === human.father {
                    return true
                }
                return false
            }))!):
                check(human)

                // Cousins, aunts search
            case _ where ((ofHuman.mother?.sisters?.contains(where: { (h) -> Bool in
                if h === human.mother {
                    return true
                }
                return false
            }))!):
                check(human)

                // Cousins, uncle search
            case _ where ((ofHuman.mother?.brothers?.contains(where: { (h) -> Bool in
                if h === human.father {
                    return true
                }
                return false
            }))!):
                check(human)

                // Grandparents search
            case _ where (human === ofHuman.father?.father) || (human === ofHuman.father?.mother) ||
                         (human === ofHuman.mother?.father) || (human === ofHuman.mother?.mother):
                
                ((human as? Man) != nil) ? (grandpas += 1) : (grandmas += 1)
            default:
                break
            }
        }
    }
    print("Said human has \(unclesCash.keys.count) uncles, \(auntsCash.keys.count) aunts, \(grandpas) grandpas, \(grandmas) grandmas, \(cousinBr) cousin brothers, \(cousinSis) cousin sisters, \(ofHuman.sisters?.count ?? 0) sisters and \(ofHuman.brothers?.count ?? 0) brothers")
}

let family = (man + woman).shuffled()

for person in family {
    if let p = person as? Man {
        p.moveSofa()
    } else if let p = person as? Woman {
        p.command()
    }
}

findRelatives(ofHuman: man[0])

//: Part 3
print("--------TASK III--------")

class Cat: Animal {
    override func says() {
        print("meow")
    }
}

class Dog: Animal {
    override func says() {
        print("woof")
    }
}

class Snake: Animal {
    override func says() {
        print("ssssss")
    }
}

var animals = [Animal]()

family[0].pet = [Cat()]
family[2].pet = [Dog()]
family[4].pet = [Snake()]
family[5].pet = [Cat(), Dog(), Snake()]
family[9].pet = [Cat(), Cat(), Cat(), Cat(), Cat()]
family[10].pet = [Snake(), Snake()]
family[11].pet = []
family[16].pet = [Dog(), Cat(), Dog(), Cat()]
family[17].pet = [Snake(), Dog()]
family[18].pet = []
family[25].pet = [Cat()]
family[31].pet = [Snake()]

for person in family {
    if let a = person.pet {
        animals += a
    }
}

var dogs = 0, cats = 0, snakes = 0

for animal in animals {
    
    animal.says()
    
    switch animal {
    case is Dog:
        dogs += 1
    case is Cat:
        cats += 1
    case is Snake:
        snakes += 1
    default:
        break
    }
}

print("Family has \(dogs) dogs, \(cats) cats, \(snakes) snakes" )
