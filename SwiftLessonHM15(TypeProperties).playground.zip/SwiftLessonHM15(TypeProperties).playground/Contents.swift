//: Swift Lesson 15 | Homework
//: Part 1
import UIKit

print("-------- Task I ---------")
struct FileDescription {
    
    var wayToFile : String
    
    var isHidden : Bool
    
    var maxFileSize : Int {
        
//        return MemoryLayout<String>.size
//        return MemoryLayout.size(ofValue: self.content)
        switch self.content {
        case let someInt as Int:
            return MemoryLayout.size(ofValue: someInt)
        case let someDouble as Double:
            return MemoryLayout.size(ofValue: someDouble)
        case let someString as String:
            return MemoryLayout.size(ofValue: someString)
        case let someFloat as Float:
            return MemoryLayout.size(ofValue: someFloat)
        default:
            print("Some another data type")
            return MemoryLayout.size(ofValue: self.content)
        }
    }
    
    var wayToFolder : String {
        
        var separatedWay = wayToFile.split(separator: "▸")
        
        separatedWay.remove(at: (separatedWay.count - 1))
        
        return String(separatedWay.joined(separator: "▸"))
    }
    
    var fileName : String {
        
        let separatedWay = wayToFile.split(separator: "▸")
        
        return String(separatedWay[separatedWay.count - 1])
    }
    
    var content : Any {
        
        didSet {
            
            if self.isHidden {
                
                self.content = oldValue
                
                print("File is hidden! Content editing is unavailable.")
            }
        }
    }
}

var someFile = FileDescription(wayToFile: "‎⁨iCloud Drive⁩▸⁨Desktop⁩▸⁨Swift Course⁩▸Swift Lesson 15",
                               isHidden: false,
                               content: "Content of the file")

someFile.wayToFile
someFile.wayToFolder
someFile.content
print("Name of the file = " + someFile.fileName)
someFile.maxFileSize

someFile.content = "123124"
print(someFile.content)

someFile.isHidden = true
someFile.content = UInt(666)
print(someFile.content)
someFile.maxFileSize

//: Part 2
print("-------- Task II ---------")

//If you make it conform to the CaseIterable protocol, you can use the allCases array. Which is generated automatically, and contains all the cases in the order they were defined.
enum Gamma: Int, CaseIterable {
    
    static var numberOfColors = Gamma.allCases.count
    
    static var extremeColors : (min: Int, max: Int) {
        
        var array = [Int]()
        
        for color in Gamma.allCases {
            array.append(color.rawValue)
        }
        
        return (array.min()!, array.max()!)
    }
    
    case White = 0xFFFFFF
    case Black = 0x000000
    case Blue = 0x0000FF
    case Red = 0xFF0000
    case Green = 0x00FF00
}

var someColor = Gamma.Black.rawValue
someColor = Gamma.White.rawValue
someColor = Gamma.Blue.rawValue
someColor = Gamma.Red.rawValue
someColor = Gamma.Green.rawValue

Gamma.numberOfColors
print("Smallest numeric gamma color representation: \(Gamma.extremeColors.min)")
print("Largest numeric gamma color representation: \(Gamma.extremeColors.max)")

//: Part 3
print("-------- Task III ---------")

class Human {
    
    static var countOfHumans = 0
    
    static var posibleNameLength = 3...20
    
    static var posibleAge = 0.1...150

    static var posibleHeight = 0.4...3

    static var posibleWeight = 2...600.0

    
    var firstName : String {
    
        didSet {
            if   !Human.posibleNameLength.contains(firstName.count) {
                
                firstName = oldValue
                
                print("Length of first name must be in the range: \(Human.posibleNameLength)! Setted old value of the first name.")
            }
        }
    }
    
    var lastName : String {
        
        didSet {
            if  !Human.posibleNameLength.contains(lastName.count) {
                
                lastName = oldValue
                
                print("Length of last name must be in the range: \(Human.posibleNameLength)! Setted old value of the last name.")
            }
        }
    }
    
    var age : Double {
        
        didSet {
            if  !Human.posibleAge.contains(age) {
                
                age = oldValue
                
                print("Invalid age! Age must be in the range: \(Human.posibleAge)! Setted old value of the age.")
            }
        }
    }
    
    var height : Double {
        
        didSet {
            if  !Human.posibleHeight.contains(height) {
                
                height = oldValue
                
                print("Invalid height! Height must be in the range: \(Human.posibleHeight)! Setted old value of the height.")
            }
        }
    }
    
    var weight: Double {
        
        didSet {
            if  !Human.posibleWeight.contains(weight) {
                
                weight = oldValue
                
                print("Invalid weight! Weight must be in the range: \(Human.posibleWeight)! Setted old value of the weight.")
            }
        }
    }
    
    init(firstName: String, lastName : String, age: Double, height: Double, weight: Double) {
        
        self.firstName = Human.posibleNameLength.contains(firstName.count) ? firstName : "First name initialized incorrectly"
        self.lastName = Human.posibleNameLength.contains(lastName.count) ? lastName : "Last name initialized incorrectly"
        self.age = Human.posibleAge.contains(age) ? age : 0
        self.height = Human.posibleHeight.contains(height) ? height : 0
        self.weight = Human.posibleWeight.contains(weight) ? weight : 0
        
        Human.countOfHumans += 1
    }
    
    deinit {
        Human.countOfHumans -= 1
    }
}

let human1 = Human(firstName: "Georg", lastName: "U", age: 35, height: 1.8, weight: 60)
let human2 = Human(firstName: "Stas", lastName: "Botin", age: 24, height: 1.78, weight: 65)
let human3 = Human(firstName: "NameWhichOutOfRangeIsHereForCheck", lastName: "K", age: 240, height: 5, weight: 0.1)

if true {
    _ = Human(firstName: "Alex", lastName: "Dev", age: 30, height: 182, weight: 75)
    
    Human.countOfHumans
}

Human.countOfHumans


human1.firstName = "Il"
human1.firstName

human1.lastName
human1.lastName = "Goodname"
human1.lastName

human1.age = 214
human1.age
human1.height = 5
human1.height
human1.weight = 1000
human1.weight

human3.firstName
human3.lastName
human3.age
human3.height
human3.weight
