//: Swift Lesson 11 | Homework
//: Part 1
print("--------TASK 1---------")

func counter(cl: () -> Void) {

    for i in 1...10 {
        print(i)
    }
    cl()
}

counter {print("clouser")}
//: Part 2
print("--------TASK 2---------")

let array = [4, 1, 8, 3, 143, 16, 23, 15, 42, 8]

let ascendingArray = array.sorted(by: < )
let descendingArray = array.sorted(by: > )

print(ascendingArray)
print(descendingArray)
//: Part 3
print("--------TASK 3---------")

func extremeValue (intArray: [Int], clouser: (Int?, Int) -> Bool) -> Int {
    
    var someInt: Int?
    
    for value in intArray {

        if clouser(someInt, value) || someInt == nil {
            
            someInt = value
        }
    }
    return someInt ?? 0
}

print("Maximum value = \(extremeValue (intArray: array) {$0 != nil && ($0 ?? 0) < $1})")

print("Minimum value = \(extremeValue (intArray: array) {$0 != nil && ($0 ?? 0) > $1})")
//: Part 4
print("--------TASK 4---------")

let someString = "Don’t0) Worry2@ If4$ You6^ Are3 Not5% Familiar6^ With8* The&7 Concept9( Of0 Capturing.9 It8 Is7 Explained6 In5 Detail4 Below3 In2 Capturing1 Values0."

var charsArray = [Character](someString.lowercased())

func stringSorting (arrayOfStrings array: [Character], cl: ([Character]) -> [Character]) -> String {
    
    var dict: [String:[Character]] = ["vowels":[], "consonants":[], "digits":[], "symbols":[]]
    
    for i in array {

        switch i {
            
        case "a", "e", "i", "o", "u": //"A", "E", "I", "O", "U",
            dict["vowels"]?.append(i)
            
        case "a"..."z":
            dict["consonants"]?.append(i)
            
        case "0"..."9":
            dict["digits"]?.append(i)
            
        case " ":
            continue
            
        default:
            dict["symbols"]?.append(i)
        }
    }
    
    for key in dict.keys {

        dict[key] = cl(dict[key]!)
    }
    
    return String(dict["vowels"]! + dict["consonants"]! + dict["digits"]! + dict["symbols"]!)
}

print(stringSorting(arrayOfStrings: charsArray) {$0.sorted(by: < )})
//: Part 5 (Part 3 for string)
print("--------TASK 5---------")

func extremeValueOfString (str: String, clouser: (UInt32?, UInt32) -> Bool) -> Character {
    
    var optVal: Unicode.Scalar?
    
    for i in str.unicodeScalars {
        //print("Scalar value of \(Character(i)) = \(i.value)")
        if (clouser(optVal?.value, i.value) || optVal == nil) && Character(i) != " " {
            
            optVal = Unicode.Scalar?(i)
        }
    }
    
    return Character(optVal ?? "0")
}

print("Character with maximum scaral value: \(extremeValueOfString(str: someString) {$0 != nil && ($0 ?? 0) < $1})")
print("Character with minimum scaral value: \(extremeValueOfString(str: someString) {$0 != nil && ($0 ?? 0) > $1})")
