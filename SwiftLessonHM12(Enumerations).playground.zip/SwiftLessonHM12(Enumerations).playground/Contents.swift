//: Swift Lesson 12 | Homework
//: Part 1
print("----------Task #1-----------")

enum Color : String {
    case Black = "Black"
    case White = "White"
}

enum Position : String {
    case a = "a"
    case b = "b"
    case c = "c"
    case d = "d"
    case e = "e"
    case f = "f"
    case g = "g"
    case h = "h"
}

enum ChessmanName : String {
    case King = "King"
    case Queen = "Queen"
    case Rook = "Rook"
    case Bishop = "Bishop"
    case Knight = "Knight"
    case Pawn = "Pawn"
}

enum ChessPiece {
    case King(name: ChessmanName, x: Position, y: Int, Color: Color)
    case Queen(name: ChessmanName, x: Position, y: Int, Color: Color)
    case Rook(name: ChessmanName, x: Position, y: Int, Color: Color)
    case Bishop(name: ChessmanName, x: Position, y: Int, Color: Color)
    case Knight(name: ChessmanName, x: Position, y: Int, Color: Color)
    case Pawn(name: ChessmanName, x: Position, y: Int, Color: Color)
}

var blackKing = ChessPiece.King(name: .King, x: .e, y: 5, Color: .Black)
var blackPawn1 = ChessPiece.Pawn(name: .Pawn, x: .b, y: 6, Color: .Black)
var blackRook1 = ChessPiece.Rook(name: .Rook, x: .b, y: 2, Color: .Black)
var blackKnight1 = ChessPiece.Knight(name: .Knight, x: .g, y: 7, Color: .Black)

var whiteKing = ChessPiece.King(name: .King, x: .d, y: 1, Color: .White)
var whiteQueen = ChessPiece.Queen(name: .Queen, x: .d, y: 4, Color: .White)
var whitePawn = ChessPiece.Pawn(name: .Pawn, x: .e, y: 3, Color: .White)
var whiteBishop = ChessPiece.Bishop(name: .Bishop, x: .h, y: 3, Color: .White)

var chessPiecesArray = [blackKing, blackPawn1, blackRook1, blackKnight1, whiteKing, whiteQueen, whitePawn, whiteBishop]
//: Part 2
print("----------Task #2-----------")

func printer (chessPiece: ChessPiece) -> () {
    
    switch chessPiece {
    case let .King(name, x, y, col):
        print("Chess piece with name: \(name), color: \(col), position: \(x)\(y)")
        
    case let .Queen(name, x, y, col):
        print("Chess piece with name: \(name), color: \(col), position: \(x)\(y)")
        
    case let .Rook(name, x, y, col):
        print("Chess piece with name: \(name), color: \(col), position: \(x)\(y)")
        
    case let .Bishop(name, x, y, col):
        print("Chess piece with name: \(name), color: \(col), position: \(x)\(y)")
        
    case let .Knight(name, x, y, col):
        print("Chess piece with name: \(name), color: \(col), position: \(x)\(y)")
        
    case let .Pawn(name, x, y, col):
        print("Chess piece with name: \(name), color: \(col), position: \(x)\(y)")
    }
}

for i in chessPiecesArray {
    printer(chessPiece: i)
}
//: Part 3
//func chessBoard (ChessmanName: [ChessPiece]) -> () {
//
//    for j in 1...8 {
//
//        var chessLine : [Position: String] = [:]
//
//        let w = "\u{2B1C}" // UniCode of white cell
//        let b = "\u{2B1B}" // UniCode of black cell
//
//        var cellValue : String
//
//        if j % 2 != 0 {
//            chessLine = [Position(rawValue: "a")!:w, Position(rawValue: "b")!:b, Position(rawValue: "c")!:w, Position(rawValue: "d")!:b,        Position(rawValue: "e")!:w, Position(rawValue: "f")!:b, Position(rawValue: "g")!:w, Position(rawValue: "h")!:b]
//
//        } else {
//            chessLine = [Position(rawValue: "a")!:b, Position(rawValue: "b")!:w, Position(rawValue: "c")!:b, Position(rawValue: "d")!:w, Position(rawValue: "e")!:b, Position(rawValue: "f")!:w, Position(rawValue: "g")!:b, Position(rawValue: "h")!:w]
//        }
//
//        for i in ChessmanName {
//
//            switch i {
//
//            case .King( _, let x, let y, let col) where y == j:
//                col == .White ? (chessLine[x] = "\u{2654}") : (chessLine[x] = "\u{265A}")
//
//            case .Queen( _, let x, let y, let col) where y == j:
//                col == .White ? (chessLine[x] = "\u{2655}") : (chessLine[x] = "\u{265B}")
//
//            case .Rook( _, let x, let y, let col) where y == j:
//                col == .White ? (chessLine[x] = "\u{2656}") : (chessLine[x] = "\u{265C}")
//
//            case .Bishop( _, let x, let y, let col) where y == j:
//                col == .White ? (chessLine[x] = "\u{2657}") : (chessLine[x] = "\u{265D}")
//
//            case .Knight( _, let x, let y, let col) where y == j:
//                col == .White ? (chessLine[x] = "\u{2658}") : (chessLine[x] = "\u{265E}")
//
//            case .Pawn( _, let x, let y, let col) where y == j:
//                col == .White ? (chessLine[x] = "\u{2659}") : (chessLine[x] = "\u{265F}")
//
//            default:
//                break
//            }
//        }
//        print(chessLine[Position(rawValue: "a")!]! + chessLine[Position(rawValue: "b")!]! + chessLine[Position(rawValue: "c")!]! + chessLine[Position(rawValue: "d")!]! + chessLine[Position(rawValue: "e")!]! + chessLine[Position(rawValue: "f")!]! + chessLine[Position(rawValue: "g")!]! + chessLine[Position(rawValue: "h")!]!)
//
//        chessLine.removeAll(keepingCapacity: false)
//    }
//}
//: Part 3
print("----------Task #3-----------")

func chessBoard (cheMan: [ChessPiece]) -> () {
    
    for j in (1...8).reversed() { // Line (y) from Up to Down
        
        var line = "\(j) "
        
        var intEqOfI = 0
        
        counter: for i in "abcdefgh" { // Column (x)
            
            intEqOfI += 1
            
            for f in cheMan { // Сomparing the position of the chessman with the position of the cell being processed
                
                switch f {
                    
                case let .King( _, x, y, col) where y == j && Character(x.rawValue) == i:
                    line.append(contentsOf: col == .White ? "\u{2654}" : "\u{265A}")
                    continue counter
                    
                case let .Queen( _, x, y, col) where y == j && Character(x.rawValue) == i:
                    line.append(contentsOf: col == .White ? "\u{2655}" : "\u{265B}")
                    continue counter
                    
                case let .Rook( _, x, y, col) where y == j && Character(x.rawValue) == i:
                    line.append(contentsOf: col == .White ? "\u{2656}" : "\u{265C}")
                    continue counter
                    
                case let .Bishop( _, x, y, col) where y == j && Character(x.rawValue) == i:
                    line.append(contentsOf: col == .White ? "\u{2657}" : "\u{265D}")
                    continue counter
                    
                case let .Knight( _, x, y, col) where y == j && Character(x.rawValue) == i:
                    line.append(contentsOf: col == .White ? "\u{2658}" : "\u{265E}")
                    continue counter
                    
                case let .Pawn( _, x, y, col) where y == j && Character(x.rawValue) == i:
                    line.append(contentsOf: col == .White ? "\u{2659}" : "\u{265F}")
                    continue counter
                    
                default:
                    break
                }
            }
            line.append(contentsOf: (j + intEqOfI) % 2 != 0 ? "\u{2B1C}" : "\u{2B1B}")
        }
        print(line)
    }
    print("   a b c d e f g h")
    print("")
}

chessBoard(cheMan: chessPiecesArray)
//: Part 4
print("----------Task #4-----------")

func move (chessman: inout ChessPiece, newPos: (newX: String, newY: Int)) -> () {
    
    let chessIndex = ["a":1, "b":2, "c":3, "d":4, "e":5, "f":6, "g":7, "h":8]
    
    // Clouser checking that the new position matches the old one
    let isSamePosition = { (x: Position, y: Int) -> Bool in
        return (y == newPos.newY && (chessIndex[x.rawValue]!) == (chessIndex[newPos.newX]!))
    }

    // Сheck of new position for compliance with cheesboard coordinates
    if ("a"..."h").contains(newPos.newX) && (1...8).contains(newPos.newY) {

        switch chessman {
        case let .King(n, x, y, col) where ((chessIndex[(x.rawValue)]! - 1)...(chessIndex[(x.rawValue)]! + 1)).contains(chessIndex[newPos.newX]!) && // Сheck of chessman move
                                           ((y - 1)...(y + 1)).contains(newPos.newY) &&
                                           !isSamePosition(x,y):
            
            chessman = ChessPiece.King(name: n, x: Position(rawValue: newPos.newX)!, y: newPos.newY, Color: col)
            print("\(col) \(n) moves from \"\(x)\(y)\" to \"\(newPos.newX)\(newPos.newY)\"")
            
        case let .Queen(n, x, y, col) where (((x.rawValue) == newPos.newX && (1...8).contains(newPos.newY)) ||
                                            (("a"..."h").contains(newPos.newX) && y == newPos.newY)) ||
                                            (abs(chessIndex[newPos.newX]! - chessIndex[(x.rawValue)]!) == abs(newPos.newY - y)) &&
                                            !isSamePosition(x,y):
            
            chessman = ChessPiece.Queen(name: n, x: Position(rawValue: newPos.newX)!, y: newPos.newY, Color: col)
            print("\(col) \(n) moves from \"\(x)\(y)\" to \"\(newPos.newX)\(newPos.newY)\"")
            
        case let .Rook(n, x, y, col) where (((x.rawValue) == newPos.newX && (1...8).contains(newPos.newY)) ||
                                           (("a"..."h").contains(newPos.newX) && y == newPos.newY)) &&
                                           !isSamePosition(x,y):
                                        
            chessman = ChessPiece.Rook(name: n, x: Position(rawValue: newPos.newX)!, y: newPos.newY, Color: col)
            print("\(col) \(n) moves from \"\(x)\(y)\" to \"\(newPos.newX)\(newPos.newY)\"")
            
        case let .Bishop(n, x, y, col) where (abs(chessIndex[newPos.newX]! - chessIndex[(x.rawValue)]!) == abs(newPos.newY - y)) &&
                                             !isSamePosition(x,y):
            
            chessman = ChessPiece.Bishop(name: n, x: Position(rawValue: newPos.newX)!, y: newPos.newY, Color: col)
            print("\(col) \(n) moves from \"\(x)\(y)\" to \"\(newPos.newX)\(newPos.newY)\"")
            
        case let .Knight(n, x, y, col) where ((abs(chessIndex[newPos.newX]! - chessIndex[(x.rawValue)]!) + abs(newPos.newY - y)) == 3) &&
                                             !isSamePosition(x,y):
            
            chessman = ChessPiece.Knight(name: n, x: Position(rawValue: newPos.newX)!, y: newPos.newY, Color: col)
            print("\(col) \(n) moves from \"\(x)\(y)\" to \"\(newPos.newX)\(newPos.newY)\"")
            
        case let .Pawn(n, x, y, col) where (x.rawValue == newPos.newX) &&
                                           ((y - 1)...(y + 1)).contains(newPos.newY) &&
                                           !isSamePosition(x,y):
            
            chessman = ChessPiece.Pawn(name: n, x: Position(rawValue: newPos.newX)!, y: newPos.newY, Color: col)
            print("\(col) \(n) moves from \"\(x)\(y)\" to \"\(newPos.newX)\(newPos.newY)\"")
            
        default:
            print("New position set incorrectly!")
        }
        // Update array of chess pieces
        chessPiecesArray = [blackKing, blackPawn1, blackRook1, blackKnight1, whiteKing, whiteQueen, whitePawn, whiteBishop]
        
    } else {
        print(">>>ERROR: setted position \"\(newPos.newX)\(newPos.newY)\" is out of chessboard!<<<")
    }
}

move(chessman: &blackKing, newPos: (newX: "e", newY: 6))
move(chessman: &blackRook1, newPos: (newX: "b", newY: 5))
move(chessman: &blackKnight1, newPos: (newX: "f", newY: 5))
move(chessman: &whiteBishop, newPos: (newX: "f", newY: 0))
move(chessman: &whiteQueen, newPos: (newX: "d", newY: 8))

chessBoard(cheMan: chessPiecesArray)
