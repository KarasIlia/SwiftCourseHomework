//:Swift Lesson 10 | Homework
//:Part 1
print("-----------------Part 1-----------------")

func watch() -> String {
    return "\u{231A}"
}

func radSign() -> String {
    return "\u{2622}"
}

func letsRock() -> String {
    return "\u{1F918}"
}

print(watch() + radSign() + letsRock())
print("-----------------Part 2-----------------")
//:Part 2
func blackOrWhite (hor: String, ver: Int) -> String? {
    
    let horDict = ["a":1, "b":2, "c":3, "d":4, "e":5, "f":6, "g":7, "h":8]
    
    return ((horDict[hor.lowercased()]! + ver) % 2 == 0) ? "black" : "white"
}

let cell = (x:"e", y:7)

print("Cell \"\(cell.x)\(cell.y)\" is \(blackOrWhite(hor: cell.x, ver: cell.y)!)")
print("----------------Part 3------------------")
//:Part 3
func revers(array: [Int]) -> [Int] {
    let revArray = array.reversed()
    return [Int](revArray)
}

var array = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

print(array)

print(revers(array: array))

print(array)

func revArray(fromRange range: Int...) -> [Int] {
    let array2 = revers(array: range)
    return array2
}

print(revArray(fromRange: 4,8,15,16,23,42))
print("-----------------Part 4-----------------")
//:Part 4
func rever(inputArray array: inout [Int]) -> [Int] {
    array = array.reversed()
    return [Int](array)
}
print(array)

rever(inputArray: &array)

print(array)
print("-----------------Part 5-----------------")
//:Part 5
var string = "0 Functions are self-contained chunks of code that perform a specific task.1 You give a function a name that identifies what it does,2 and this name is used to “call” the function to perform its task when needed.3"

func textEditor (text s: inout String) {
    s = s.lowercased()
    
    var s2: String = ""
    
    let dict = [0:"ZERO", 1:"ONE", 2:"TWO", 3:"THREE", 4:"FOUR",
                5:"FIVE", 6:"SIX", 7:"SEVEN", 8:"EIGHT", 9:"NINE"]
    
    for i in s  {
        
        switch i {
        case _ where i == "," || i == "." || i == "?" || i == "!":
            let i2 = " "
            s2.append(i2)
            
        case _ where i == "a" || i == "e" || i == "i" || i == "o" || i == "u":
            let i2 = String(i).uppercased()
            s2.append(i2)
            
        case _ where "0123456789".contains(i):
            let i2 = dict[Int(String(i))!]
            s2.append(i2!)
            
        default:
            let i2 = i
            s2.append(i2)
        }
    }
    s = s2
}

print(string)
textEditor(text: &string)

print("EDITED TEXT:")
print(string)
