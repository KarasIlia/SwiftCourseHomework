//: Swift Lesson 14 | Homework
//: Part 1
//: Part 1
print("---------TASK 1 & 2----------")
import Foundation

struct Now {
    static let day = 18
    static var month = 3
    static var year = 2019
}

struct Birthdate {
    
    var day : Int
    var month : Int
    var year : Int
    
    var age : Int {
        return ((Now.month - month > 0)  || (Now.month == month && Now.day - day >= 0) ? (Now.year - year)
                                                                                       : (Now.year - year - 1))
    }
    
    var studingYears : Int {
        return age <= 6 ? 0 : age - 6
    }
}

struct Student {
    
    var birthday : Birthdate
    
    var firstName : String {
        
        willSet {
            print(newValue + " will set instead of " + firstName)
        }
        
        didSet {
            firstName = firstName.capitalized

            print(firstName + " did set instead of " + oldValue)
        }
    }
    
    var lastName : String {
        
        didSet {
            lastName = lastName.capitalized
            
            print(lastName + " did set instead of " + oldValue)
        }
    }
    
    var fullName : String {
        
        get {
            return firstName + " " + lastName
        }
        
        set {
            print("Full name want be set to " + newValue)
            
            let words = newValue.components(separatedBy: " ")
            
            if words.count > 0 {
                firstName = words[0]
            }
            
            if words.count > 1 {
                lastName = words[1]
            }
        }
    }
}


var student = Student(birthday: .init(day: 19, month: 3, year: 1994), firstName: "Ilia", lastName: "Karas")

student.firstName

student.firstName = "OLEG"

student.firstName

student.fullName

student.fullName = "OZZY OSBOURNE"

student.firstName
student.lastName
student.fullName

student.birthday.age
student.birthday.studingYears
//: Part 2
print("---------TASK 3 & 4----------")
struct Segment {
    
    struct Point {
    
        var x: Double
        var y: Double
    }
    
    init(pointA: Point, pointB: Point) {
        
        self.pointA = Point(x: pointA.x, y: pointA.y)
        self.pointB = Point(x: pointB.x, y: pointB.y)
//        self.sin = (pointB.y - pointA.y) / length
//        self.cos = (pointB.x - pointA.x) / length
    }
    
    var pointA : Point
    var pointB : Point
    
    var length : Double {
        
        get {
            return sqrt(pow(pointB.x - pointA.x, 2) + pow(pointB.y - pointA.y, 2))
        }
        
        set {
            pointB = Point(x: (pointA.x + newValue * (pointB.x - pointA.x) / length),
                           y: (pointA.y + newValue * (pointB.y - pointA.y) / length))
        }
    }
    
    var middlePoint : Point {
        
        get {
            return Point(x: pointA.x + (pointB.x - pointA.x) / 2, y: pointA.y + (pointB.y - pointA.y) / 2)
        }
        
        set {
            let tempLength = length
            
            pointA = Point(x: newValue.x - ((pointB.x - pointA.x) / tempLength) * tempLength/2,
                           y: newValue.y - ((pointB.y - pointA.y) / tempLength) * tempLength/2)
            
            pointB = Point(x: newValue.x + ((pointB.x - pointA.x) / tempLength) * tempLength/2,
                           y: newValue.y + ((pointB.y - pointA.y) / tempLength) * tempLength/2)
        }
    }
}

var otrezok = Segment(pointA: .init(x: 0, y: 0), pointB: .init(x: 5, y: 20))

otrezok.length
print("Point \"A\": \(otrezok.pointA)")
print("Point \"B\": \(otrezok.pointB)")
print("Middle point: \(otrezok.middlePoint)")

otrezok.length = 18
otrezok.length
print("Point \"A\": \(otrezok.pointA)")
print("Point \"B\": \(otrezok.pointB)")
print("Middle point: \(otrezok.middlePoint)")
otrezok.length

otrezok.middlePoint = .init(x: 30, y: 10)
print("Point \"A\": \(otrezok.pointA)")
print("Point \"B\": \(otrezok.pointB)")
print("Middle point: \(otrezok.middlePoint)")
otrezok.length

otrezok.pointA = .init(x: 1, y: 1)
otrezok.pointB = .init(x: 2, y: -2)
print("Point \"A\": \(otrezok.pointA)")
print("Point \"B\": \(otrezok.pointB)")
print("Middle point: \(otrezok.middlePoint)")
otrezok.length
otrezok.length = 10
print("Point \"A\": \(otrezok.pointA)")
print("Point \"B\": \(otrezok.pointB)")
print("Middle point: \(otrezok.middlePoint)")
otrezok.length

otrezok.pointA = .init(x: 0, y: 0)
otrezok.pointB = .init(x: 1000, y: 10)
print("Point \"A\": \(otrezok.pointA)")
print("Point \"B\": \(otrezok.pointB)")
print("Middle point: \(otrezok.middlePoint)")
otrezok.length
