
//:Swift Lesson 2 - Homework

print("""
    Int maximum = \(Int.max)\nInt minimum = \(Int.min)\n
    UInt8 maximum = \(UInt8.max)\nUInt8 minimum = \(UInt8.min)\n
    Int8 maximum = \(Int8.max)\nInt8 minimum = \(Int8.min)
    """)

let integer         = 14
let float  : Float  = 3.1
let double          = 4.9

let IntSum     = Int(Double(integer) + Double(float) + double)
let floatSum   = Float(integer)      + float         + Float(double)
let doubleSum  = Double(integer)     + Double(float) + double

if Double(IntSum) < doubleSum {
    print("Double is more accurate than Integer!")
} else if Double(IntSum) == doubleSum {
    print("Integer is more accurate than Double!")
} else {
    print("Int is equal")
}
