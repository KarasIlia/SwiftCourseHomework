//: Swift Lesson 13 | Homework
//: Part 1
import UIKit

struct Student {
    var firstName = "No first name"
    var lastName = "No last name"
    var yearOfBirth: Int?
    var averageRating: Double?

    init(firstName: String, lastName: String, yearOfBirth: Int?, averageRating: Double?) {
        self.firstName = firstName
        self.lastName = lastName
        self.yearOfBirth = yearOfBirth
        self.averageRating = averageRating
        journal.append(self)
    }
}

var journal : [Student] = []

var student1 = Student(firstName: "Ily", lastName: "Karas", yearOfBirth: 1994, averageRating: 4.65)
var student2 = Student(firstName: "Stas", lastName: "Blade", yearOfBirth: 2005, averageRating: 3.89)
var student3 = Student(firstName: "George", lastName: "Fist", yearOfBirth: 1997, averageRating: 1.95)
var student4 = Student(firstName: "Alex", lastName: "Karas", yearOfBirth: 1990, averageRating: 4.95)
//: Part 2
print("---------Task 2---------")

func info (journal: [Student]) -> () {
    
    var i = 1
    
    for student in journal {
        print("\(i) \(student.lastName) \(student.firstName) \(student.yearOfBirth!) \(student.averageRating!)")
        
        i += 1
    }
}

info(journal: journal)
//: Part 3
print("---------Task 3---------")

journal = journal.sorted { (Student1, Student2) -> Bool in
    Student1.averageRating! > Student2.averageRating!
}

info(journal: journal)
//: Part 4
print("---------Task 4---------")

journal = journal.sorted { (Student1, Student2) -> Bool in
    Student1.lastName == Student2.lastName ?
        Student1.firstName < Student2.firstName :
        Student1.lastName < Student2.lastName
}

info(journal: journal)
//: Part 5
print("---------Task 5---------")

var array = journal

array[0].averageRating = 10
array[1].averageRating = 100
array[2].averageRating = 1000
array[3].averageRating = 10000

print("First array:")
info(journal: journal)

print("New array:")
info(journal: array)


//: Part 6.1 (Classes)
class StudentClass {
    var firstName = "No first name"
    var lastName = "No last name"
    var yearOfBirth: Int?
    var averageRating: Double?
    
    init(firstName: String, lastName: String, yearOfBirth: Int?, averageRating: Double?) {
        self.firstName = firstName
        self.lastName = lastName
        self.yearOfBirth = yearOfBirth
        self.averageRating = averageRating
        journalClass.append(self)
    }
}

var journalClass : [StudentClass] = []

var studentClass1 = StudentClass(firstName: "Ily", lastName: "Karas", yearOfBirth: 1994, averageRating: 4.65)
var studentClass2 = StudentClass(firstName: "Stas", lastName: "Blade", yearOfBirth: 2005, averageRating: 3.89)
var studentClass3 = StudentClass(firstName: "George", lastName: "Fist", yearOfBirth: 1997, averageRating: 1.95)
var studentClass4 = StudentClass(firstName: "Alex", lastName: "Karas", yearOfBirth: 1990, averageRating: 4.95)
//: Part 6.2
print("---------Task 2 (Classes)---------")

func infoClass (journal: [StudentClass]) -> () {
    
    var i = 1
    
    for student in journal {
        print("\(i) \(student.lastName) \(student.firstName) \(student.yearOfBirth!) \(student.averageRating!)")
        
        i += 1
    }
}

infoClass(journal: journalClass)
//: Part 6.3
print("---------Task 3 (Classes)---------")

journalClass = journalClass.sorted { (Student1, Student2) -> Bool in
    Student1.averageRating! > Student2.averageRating!
}

infoClass(journal: journalClass)
//: Part 6.4
print("---------Task 4 (Classes)---------")

journalClass = journalClass.sorted { (Student1, Student2) -> Bool in
    Student1.lastName == Student2.lastName ?
        Student1.firstName < Student2.firstName :
        Student1.lastName < Student2.lastName
}

infoClass(journal: journalClass)
//: Part 6.5
print("---------Task 5 (Classes)---------")

var arrayClass = journalClass

for s in arrayClass {
    s.averageRating = 666
}

print("First class array:")
infoClass(journal: journalClass)

print("New class array:")
infoClass(journal: arrayClass)

//: PART 007 MAN, SUPERMAN
print("---------Task 007----------")

enum Color : String {
    case Black = "Black"
    case White = "White"
}

enum Position : String {
    case a = "a"
    case b = "b"
    case c = "c"
    case d = "d"
    case e = "e"
    case f = "f"
    case g = "g"
    case h = "h"
}

enum FigureType : String {
    case King = "King"
    case Queen = "Queen"
    case Rook = "Rook"
    case Bishop = "Bishop"
    case Knight = "Knight"
    case Pawn = "Pawn"
}

let chessIndex = ["a":1, "b":2, "c":3, "d":4, "e":5, "f":6, "g":7, "h":8]

class Chessman {
    
    var color: Color
    var position: (x: Position, y: Int)?
    var figure: FigureType
    var uCode: String?
    var figureMoves: (Position, Int, (newX: Position, newY: Int)) -> Bool
    
    init(color: Color, position: (x: Position, y: Int)?, figure: FigureType) {
        self.color = color
        self.position = position
        self.figure = figure
        
        switch figure {
            
        case .King:
            self.uCode = color == Color.White ? "\u{2654}" : "\u{265A}"
            self.figureMoves = { (x: Position, y: Int, newPos: (newX: Position, newY: Int)) -> Bool in
                return ((chessIndex[x.rawValue]! - 1)...(chessIndex[x.rawValue]! + 1)).contains(chessIndex[newPos.newX.rawValue]!) &&
                       ((y - 1)...(y + 1)).contains(newPos.newY)
            }
            
        case .Queen:
            self.uCode = color == Color.White ? "\u{2655}" : "\u{265B}"
            self.figureMoves = { (x: Position, y: Int, newPos: (newX: Position, newY: Int)) -> Bool in
                return (((x.rawValue) == newPos.newX.rawValue && (1...8).contains(newPos.newY)) ||
                        (("a"..."h").contains(newPos.newX.rawValue) && y == newPos.newY)) ||
                        (abs(chessIndex[newPos.newX.rawValue]! - chessIndex[(x.rawValue)]!) == abs(newPos.newY - y))
            }
            
        case .Rook:
            self.uCode = color == Color.White ? "\u{2656}" : "\u{265C}"
            self.figureMoves = { (x: Position, y: Int, newPos: (newX: Position, newY: Int)) -> Bool in
                return (((x.rawValue) == newPos.newX.rawValue && (1...8).contains(newPos.newY)) ||
                        (("a"..."h").contains(newPos.newX.rawValue) && y == newPos.newY))
            }
            
        case .Bishop:
            self.uCode = color == Color.White ? "\u{2657}" : "\u{265D}"
            self.figureMoves = { (x: Position, y: Int, newPos: (newX: Position, newY: Int)) -> Bool in
                return (abs(chessIndex[newPos.newX.rawValue]! - chessIndex[(x.rawValue)]!) == abs(newPos.newY - y))
            }
            
        case .Knight:
            self.uCode = color == Color.White ? "\u{2658}" : "\u{265E}"
            self.figureMoves = { (x: Position, y: Int, newPos: (newX: Position, newY: Int)) -> Bool in
                return ((abs(chessIndex[newPos.newX.rawValue]! - chessIndex[(x.rawValue)]!) + abs(newPos.newY - y)) == 3)
            }
            
        case .Pawn:
            self.uCode = color == Color.White ? "\u{2659}" : "\u{265F}"
            self.figureMoves = { (x: Position, y: Int, newPos: (newX: Position, newY: Int)) -> Bool in
                return (x.rawValue == newPos.newX.rawValue) &&
                       ((y - 1)...(y + 1)).contains(newPos.newY)
            }
        }

        chessFigures.append(self)
    }
    // Function of chess figure moving
    func moveTo (newX: Position, newY: Int) -> () {
        
        if ("a"..."h").contains(newX.rawValue) && (1...8).contains(newY) &&
            self.figureMoves(self.position!.x, self.position!.y, (newX, newY)) &&
            !(self.position?.y == newY && (self.position!.x == newX)) {
            
            print("Figure \(self.color.rawValue) \(self.figure.rawValue) moves from \((self.position?.x.rawValue)!)\((self.position?.y)!) to \(newX.rawValue)\(newY)")
            
            self.position?.x = newX
            self.position?.y = newY
            
        } else {
            print(">>>ERROR: new position \"\(newX)\(newY)\" set incorrectly!")
        }
    }
    
    func romeveFig () -> () {
        self.position = nil
    }
}

// Function of chessboard printing:
func chessboardPrint () -> () {
    
    for j in (1...8).reversed() { // Line (y) from Up to Down
        
        var line = "\(j) "
        
        var intEqOfI = 0
        
        counter: for i in "abcdefgh" { // Column (x)
            
            intEqOfI += 1
            
            for f in chessFigures { // Сomparing the position of the chessman with the position of the cell being processed
                
                if f.position!.y == j && f.position!.x.rawValue == String(i) {
                    
                    line.append(f.uCode!)
                    
                    continue counter
                }
            }
            
            line.append(contentsOf: (j + intEqOfI) % 2 != 0 ? "\u{2B1C}" : "\u{2B1B}")
        }
        
        print(line)
    }
    
    print("   a b c d e f g h")
    print("")
}


var chessFigures: [Chessman] = []

var blackKing = Chessman(color: .Black, position: (.e,5), figure: .King)
var blackPawn1 = Chessman(color: .Black, position: (.b,6), figure: .Pawn)
var blackRook1 = Chessman(color: .Black, position: (.b,5), figure: .Rook)
var blackKnight1 = Chessman(color: .Black, position: (.g,7), figure: .Knight)

var whiteKing = Chessman(color: .White, position: (.d,1), figure: .King)
var whiteQueen = Chessman(color: .White, position: (.d,4), figure: .Queen)
var whitePawn1 = Chessman(color: .White, position: (.e,3), figure: .Pawn)
var whiteBishop1 = Chessman(color: .White, position: (.h,3), figure: .Bishop)
var whiteKnight1 = Chessman(color: .White, position: (.f,1), figure: .Knight)


func printChessmanInfo (chess: Chessman) -> () {
    print("Chess piece with name: \(chess.figure), color: \(chess.color), position: \((chess.position?.x)!)\((chess.position?.y)!)")
}

for ch in chessFigures {
    
    printChessmanInfo(chess: ch)
}


chessboardPrint()

whiteQueen.moveTo(newX: .b, newY: 2)
blackKnight1.moveTo(newX: .e, newY: 8)
whiteBishop1.moveTo(newX: .c, newY: 8)
blackRook1.moveTo(newX: .a, newY: 4)

chessboardPrint()









//print("VARIANT 2")
//
//var dictionary: [Int:[Int:String]] = [:]
//var dict = [Int:String]()
//
//func setEmptyDesk () -> () {
//
//    for i in (1...8).reversed() {
//
//        for j in 1...8 {
//            dict[j] = (i + j) % 2 != 0 ? "\u{2B1C}" : "\u{2B1B}"
//
//            dictionary[i] = dict
//
//        }
//    }
//}

//func printDesk () -> () {
//
//    for i in (1...8).reversed() {
//
//        var line = ""
//
//        for j in (1...8) {
//
//            if dictionary[i]![j] == nil {
//
//            dictionary[j]![j] = (i + j) % 2 != 0 ? "\u{2B1C}" : "\u{2B1B}"
//            }
//
//            line.append(dictionary[i]![j]!)
//        }
//        print(i,line)
//    }
//    print("   a b c d e f g h")
//}
//
//setEmptyDesk()
//
//blackKing = Chessman(color: .Black, position: (.e,5), figure: .King)
//blackPawn1 = Chessman(color: .Black, position: (.b,6), figure: .Pawn)
//blackRook1 = Chessman(color: .Black, position: (.b,5), figure: .Rook)
//blackKnight1 = Chessman(color: .Black, position: (.g,7), figure: .Knight)
//
//whiteKing = Chessman(color: .White, position: (.d,1), figure: .King)
//whiteQueen = Chessman(color: .White, position: (.d,4), figure: .Queen)
//whitePawn1 = Chessman(color: .White, position: (.e,3), figure: .Pawn)
//whiteBishop1 = Chessman(color: .White, position: (.h,3), figure: .Bishop)
//whiteKnight1 = Chessman(color: .White, position: (.f,1), figure: .Knight)
//
//printDesk()
//
//blackKnight1.moveTo(newX: .e, newY: 8)
//
//printDesk()
//
//blackKnight1.moveTo(newX: .d, newY: 6)
//
//printDesk()
