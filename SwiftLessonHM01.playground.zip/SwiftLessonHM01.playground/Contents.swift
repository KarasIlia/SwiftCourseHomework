
let studentName = "Bender"
let studentLastName = "Rodriguez"
let studentMidleName = "Bending"
let studentFullName = "\(studentName) \(studentMidleName) \(studentLastName)"
let studentAge = 1066
let studentHeight = 1.8
let studentWeight = 238

print("Information about student:\nStudent full name: \(studentFullName)\n\(studentName) age: \(studentAge) years\n\(studentName) weight: \(studentWeight) kg\n\(studentName) height: \(studentHeight) m")
