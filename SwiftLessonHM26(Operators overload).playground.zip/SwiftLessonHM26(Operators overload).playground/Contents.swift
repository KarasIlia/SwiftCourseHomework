//: Swift Lesson 26 | Operators overload | Homework
//: Part 1
print("-----------TASK I------------")
struct Point {
    var x: Int
    var y: Int
}

var p1 = Point(x: 5, y: 5)
var p2 = Point(x: 2, y: 2)

func - (a: inout Point, b: Point) -> Point {
    a.x -= b.x
    a.y -= b.y
    return a
    
}

print(p1 - p2)

func -= (a: inout Point, b: Int) -> Point {
    a.x -= b
    a.y -= b
    return a
}

print(p2 -= 1)

postfix func -- (a: inout Point) -> Point {
    let b = a
    a -= 1
    return b
}

print(p1--)
print(p1)

prefix func -- (a: inout Point) -> Point {
    return a -= 1
}

print(--p1)

func / (a: inout Point, b: Point) -> Point {
    a.x /= b.x
    a.y /= b.y
    return a
}

p1 = Point(x: 6, y: 6)
p2 = Point(x: 2, y: 2)

print(p1 / p2)

func /= (a: inout Point, b: Int) -> Point {
    a.x /= b
    a.y /= b
    return a
}

print(p1 /= 3)

func *= (a: inout Point, b: Int) -> Point {
    a.x *= b
    a.y *= b
    return a
}

print(p1 *= 5)
//: Part 2
print("----------TASK II----------")

import UIKit

struct Size {
    
    var height: Int
    var width: Int
}

struct Rect {
    
    var origin: Point
    var size: Size
}

var rect1 = Rect(origin: Point(x: 1, y: 3), size: Size(height: 2, width: 5))
var rect2 = Rect(origin: Point(x: 2, y: 1), size: Size(height: 3, width: 3))

func + (left: Rect, right: Rect) -> Rect {
    
    let origin = Point(x: min(left.origin.x, right.origin.x), y: min(left.origin.y, right.origin.y))
    
    let size = Size(height: max(left.origin.y + left.size.height, (right.origin.y + right.size.height) - origin.y),
                    width: max(left.origin.x + left.size.width, (right.origin.x + right.size.width) - origin.x))

    let rect = Rect(origin: origin, size: size)
    
    return rect
}

func += (left: inout Rect, right: Rect) {
    left = left + right
}

func - (left: Rect, right: Rect) -> Rect {
    
    let size = Size(height: abs(left.size.height - right.size.height), width: abs(left.size.width - right.size.width))
    var origin = Point(x: left.origin.x, y: left.origin.y)
    
    if left.size.height < right.size.height {
        origin.y = left.origin.y - size.height
    }
    
    if left.size.width < right.size.width {
        origin.x = left.origin.x - size.width
    }
    
    let rect3 = Rect(origin: origin, size: size)
    
    return rect3
}

func -= (left: inout Rect, right: Rect) {
    left = left - right
}

print(rect2 + rect1)
rect2 += rect1
print(rect2)

var rect3 = Rect(origin: Point(x: 1, y: 1), size: Size(height: 3, width: 3))
var rect4 = Rect(origin: Point(x: 5, y: 5), size: Size(height: 1, width: 4))

print(rect3 - rect4)
rect3 -= rect4
print(rect3)
//: Part 3
print("----------TASK III----------")

func + (str: String, i: Int) -> String {
    return str + String(i)
}

func += (str: inout String, i: Int) {
    str = str + String(i)
}

var string = "12345"

string + 6789
print(string)

string += 6789
print(string)

//: Part 4
print("----------TASK IV----------")

infix operator ==^

func ==^ (s1: inout String, s2: String) {
    
    var s3 = ""
    
    for char in s1.lowercased() {
        if s2.lowercased().contains(char){
            s3 += char.uppercased()
        } else {
            s3.append(char)
        }
    }
    s1 = s3
}

var s1 = "Programming is very cool!"
var s2 = "Pivo"

s1 ==^ s2
print(s1)
