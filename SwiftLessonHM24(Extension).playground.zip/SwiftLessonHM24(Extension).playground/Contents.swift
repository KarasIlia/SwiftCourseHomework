//: Swift Lesson 24 | Extension
//: Part 1...3
extension Int {
    
    var isNegative: Bool {
        if self < 0 {
            return true
        }
        return false
    }
    
    var isPositive: Bool {
        return !isNegative
    }
    
    var bool: Bool {
        if self == 0 {
            return false
        } else {
            return true
        }
    }
    
    var length: Int {
        return String(self).count
    }
    
    subscript (_ charOfIndex: Int) -> Int {
        
        get {
            var temp = self
            var i = 0
            
            while i != abs(charOfIndex) {
                temp /= 10
                i += 1
            }
        
            return (temp % 10)
        }
        
        set {
            var digitsArray = [String]()
            var j = 0
            
            for i in String(self).reversed() {
                j == charOfIndex ? digitsArray.append(String(newValue)) : digitsArray.append(String(i))
                j += 1
            }
            
            self = Int(digitsArray.reversed().joined())!
        }
    }
}

(-5).isPositive
(-5).isNegative

(-5).bool
0.bool
5.bool

1234567.length

var a = 9876543210
a[7]
a[0] = 5
a
a[9] = 666
a
//: Part 4
extension String {
    
    subscript(_ range: Range<Int>) -> String {
        
        get {
            var startInd = self.startIndex
            var endInd = self.endIndex
            
            if range.lowerBound >= 0 {
                startInd = self.index(startIndex, offsetBy: range.lowerBound, limitedBy: self.endIndex)!
            }
            
            if let end  = self.index(startIndex, offsetBy: range.upperBound, limitedBy: self.endIndex) {
                endInd = end
            }
            
            return String(self[startInd..<endInd])
        }
        
        set {
            let left = self[0..<range.lowerBound]
            var right = ""
            
            if self.count - 1 > range.upperBound {
                right = String(self.suffix(self.count - range.upperBound))
            }
            
            self = String(left) + newValue + String(right)
        }
    }
}

var str = "0123456789"
str[7..<20]
str[-5..<8]
str[1..<5]

str[1..<9] = "55"
str
str[4..<5] = "9999"
str
str[0..<3] = "666"
str
//: Part 5
extension String {
    
    mutating func truncate(_ length: Int) -> String {
        
        if length > (self.count - 1) {
            return self
        } else {
            return self[0..<length] + "..."
        }
    }
}

str.truncate(6)
str.truncate(20)
