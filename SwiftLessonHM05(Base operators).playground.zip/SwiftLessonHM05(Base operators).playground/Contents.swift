//: Swift Lesson 05 | Homework
//: Part 1
let month = 8
let birthDay = 15
var days = 0

for i in 1...month {        // Count the number of days from the beginning of the year to the birthday
    
    if i == month {
        days = days + (birthDay - 1)    // Days in month when i was born
    } else if (i == 1 || i == 3 || i == 5 || i == 7 || i == 8 || i == 10 || i == 12) {
        days += 31          // Accounting for months with 31 days
    } else if i == 2 {
        days += 28          // Month with 28 days (February)
    } else {
        days += 30          // Accounting for months with 30 days
    }
}

let seconds = days * 24 * 60 * 60

if month < 13 && birthDay < 32 {
    print("\(seconds) seconds passed from the beginning of the year to my birthday.")
} else {
    print("Invalid data entered.")
}
//: Part 2
if month >= 1 && month < 4 {
    print("I was born in the first quarter of the year.")
} else if month >= 4 && month < 7 {
    print("I was born in the second quarter of the year.")
} else if month >= 7 && month < 10 {
    print("I was born in the third quarter of the year.")
} else if month >= 10 && month < 13 {
    print("I was born in the fourth quarter of the year.")
} else {
    print("Invalid data entered.")
}
//: Part 3
var (i, j, k, l, m) = (10, 3, 5, 2, 12)

let result = i * l - j + m / j + k
//:Part 4
let (a, b, c, d, e, f, g, h) = (1, 2, 3, 4, 5, 6, 7, 8)

let cell = (x: a, y: 4)

if (cell.x > 8) && (cell.y > 8) {
    
    print("Invalid data entered.")
    
} else if ((cell.x + cell.y) % 2 == 0) {
    
    print("Cell is black")
    
} else {
    
    print("Cell is white")
}
