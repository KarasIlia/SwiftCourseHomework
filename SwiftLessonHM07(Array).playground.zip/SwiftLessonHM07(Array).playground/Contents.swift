//:Swift Lesson 07 | Homework
//:Part 1
let monthDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30 ,31]

for daysInMonth in monthDays {
    
    print(daysInMonth)
}

let months = ["January", "February", "March", "April", "May",
              "June", "July", "August", "September",
              "October", "November", "December"]

print("--------------------")

for (month, days) in monthDays.enumerated() {
    
    print("\(days) days in \(months[month])")
}

print("--------------------")

var arrayOfTuples = [(month: String, monthDays: Int)]() //Сreating an empty array of tuples !

for (month, days) in monthDays.enumerated() {
    
    print("\(days) days in \(months[month])")
    
    let monthTuple = (month: months[month], monthDays: days) // Сreating a tuple
    
    arrayOfTuples.append(monthTuple) // Adding a tuple to an array of tuples
}

print("--------------------")

for (month, monthDays) in arrayOfTuples {
    
    print("\(monthDays) days in \(month)") // Printing tuple parameters of array of tuples
}

print("--------------------")

for (month, monthDays) in arrayOfTuples.reversed() { // Reversed printing...
    
    print("\(monthDays) days in \(month)")
}

print("--------------------")

let birth = (day: 15, month: "August")

var i = 0

var daysSum = 0

repeat {
    
    daysSum += monthDays[i]
    
    i += 1
    
} while months[i] != birth.month

daysSum += (birth.day - 1)

print("Days from the beginning of the year to the specified day \(daysSum)")

print("--------------------")

//:Part 2
let optionalArray: [Int?] = [0, 1, nil, nil, 1000]

var sum = 0
// Forced unwrapping
for number in optionalArray {
    
    if number != nil {
        
        sum += number!
    }
}

print("Sum of numbers using forced unwrapping = \(sum)")

sum = 0
// Optional binding
for number in optionalArray {
    
    if let binded = number {
        
        sum += binded
    }
}

print("Sum of numbers using optional binding = \(sum)")

sum = 0
// Using operator (??)
for number in optionalArray {
    
    sum += number ?? 0
}

print("Sum of numbers using operator (??) = \(sum)")

print("--------------------")
//:Part 3
let alphabet = "abcdefghijklmnopqrstuvwxyz"

var reversedAlphabet = [String]()

for char in alphabet.reversed() {
    
    let letter = String(char)
    
    reversedAlphabet.append(letter)
}

print("Reversed alphabet: \(reversedAlphabet)")
