//: Swift Lesson 16 | Homework
import UIKit

enum Move {
    case Up
    case Down
    case Left
    case Right
}

struct Room {
    
    var width = 15
    
    var height = 10
    
    var finish = (x: 1, y: 1)
    
    func printObjectsPosition() {
        
        for p in Object.objects {
            
            if !Object.objects.isEmpty {
                
            print("Object " + p.name + " position is x: \(p.x), y: \(p.y)")
            }
        }
    }
    
    func printRoom() {
        
        print(String(repeatElement("⬛", count: width + 2)))
        
        for i in 1...self.height {
            
            var line = "⬛"
            
            mark: for j in 1...self.width {
                
                for obj in Object.objects {
                    
                    if obj.x == j && obj.y == i {
                        
                        line.append(obj.objectType)
                        
                        continue mark
                    }
                }
                
                line.append("⬜")
            }
            
            print(line + "⬛")
            
            line.removeAll()
        }
        print(String(repeatElement("⬛", count: width + 2)))
    }
}


class Object {
    
    enum ObjType: String {
        case Person = "🚶"
        case Box = "🍱"
        case Finish = "🏁"
    }
    
    let objectType: String
    
    static var objects = [Object]()
    
    let name: String
    
    let room: Room

    var x = 0 {
        didSet {
            if !(1...room.width).contains(x) {
                x = oldValue
            }
        }
    }
    
    var y = 0 {
        didSet {
            if !(1...room.height).contains(y) {
                y = oldValue
            }
        }
    }
    
    init(name: String, objType: ObjType, x: Int, y: Int, room: Room) {
        
        self.name = name
        self.x = x
        self.y = y
        self.room = room
        self.objectType = objType.rawValue
        
        Object.objects.append(self)
    }
    
    init(name: String, objType: ObjType, room: Room) {
        
        self.name = name
        self.x = room.finish.x
        self.y = room.finish.y
        self.room = room
        self.objectType = objType.rawValue
    }
    
    func moveTo (_ moves: Move...) {
        
        for m in moves {
            
            let oldX = self.x
            let oldY = self.y
            
            switch m {
            case .Up:
                self.y -= 1
            case .Down:
                self.y += 1
            case .Left:
                self.x -= 1
            case .Right:
                self.x += 1
            }
            
            for obj in Object.objects { // Проходимся по другим объектам
                
                // Если очередной объект является коробкой и его координаты совпадают с новыми координатами человека, то...
                if (obj.objectType == ObjType.Box.rawValue) && (self.x == obj.x) && (self.y == obj.y) && (self.objectType != obj.objectType) {
                    
                    let oldBoxX = obj.x
                    let oldBoxY = obj.y
                    // Пытаемся передвинуть коробку
                    obj.moveTo(m)
                    
                    if room.finish == (obj.x, obj.y) {
                        print("Box was delivered! Congratulations!")
                    }
                    // Если коробка не двигается, то возвращаем человека на старую позицию
                    if obj.x == oldBoxX && obj.y == oldBoxY {
                        
                        self.x = oldX
                        self.y = oldY
                    }
                }
            }
        }
    }
}

let room = Room(width: 10, height: 5, finish: (x: 8, y: 1))

var person = Object(name: "Human", objType: Object.ObjType.Person, x: 5, y: 3, room: room)
var box = Object(name: "Box", objType: Object.ObjType.Box, x: 7, y: 3, room: room)

var finishPoint = Object(name: "Finish", objType: Object.ObjType.Finish, x: 8, y: 1, room: room)



room.printObjectsPosition()

room.printRoom()

person.moveTo(.Right, .Right, .Right, .Down, .Right, .Up, .Up, .Up, .Up, .Up)
room.printRoom()

person.moveTo(.Right, .Up, .Left)
room.printRoom()

room.printObjectsPosition()
