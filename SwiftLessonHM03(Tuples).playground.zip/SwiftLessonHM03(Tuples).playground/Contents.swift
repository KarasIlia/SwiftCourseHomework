//: Swift Lesson 3 - Homework
var myPhys = (maxPushUps:15, maxPullUps:10, maxSquats:50)

print("My  physical training:\n\(myPhys)")

print("Maximum number of pushups  = \(myPhys.maxPushUps)")
print("Maximum number of pull-ups = \(myPhys.1)")
print("Maximum number of squats   = \(myPhys.maxSquats)")

var supermanPhys = (maxPushUps:5005, maxPullUps:3333, maxSquats:9999)

print("Superman  physical training:\n\(supermanPhys)")

var (pushUps, pullUps, squats) = (supermanPhys.maxPushUps,
                                  supermanPhys.maxPullUps,
                                  supermanPhys.maxSquats)

supermanPhys = myPhys

myPhys = (pushUps, pullUps, squats)

// After changing

print("""
    ======================================================
    -------------Let's change the rules!!!----------------
    ======================================================
    Now Superman physical training:
    \(supermanPhys)
    ------------------------------------------------------
    HA HA! NOW I'VE GOT THE POWER!!! My physical training:
    \(myPhys)
    ======================================================
    """)

var powerDifference = (pushUps: abs(supermanPhys.maxPushUps - myPhys.maxPushUps),
                       pullUps: abs(supermanPhys.maxPullUps - myPhys.maxPullUps),
                       squats:  abs(supermanPhys.maxSquats - myPhys.maxSquats))

print("""
    The difference in our strength:
    Push ups difference: \(powerDifference.pushUps)
    Pull-ups difference: \(powerDifference.pullUps)
    Squats difference:   \(powerDifference.squats)
    """)
