//:Swift Lesson 08 | Homework
//:Part 1
var marksJournal = ["Harry Potter": 3, "Philip Fry": 2, "Wang Wei": 5]

marksJournal["Harry Potter"] = marksJournal["Harry Potter"]! + 2

marksJournal["Philip Fry"] = marksJournal["Philip Fry"]! + 1

marksJournal["Eleanor Regby"] = 2

marksJournal["Ginny Weasley"] = 5

marksJournal.removeValue(forKey: "Harry Potter")

marksJournal.removeValue(forKey: "Ginny Weasley")

marksJournal

var totalScore = 0

for (_, mark) in marksJournal {
    
    totalScore += mark
}

let averageScore = Double(totalScore) / Double(marksJournal.count)

print("""
    Total score of students = \(totalScore)
    Average score of students = \(averageScore)
    ---------------------------------
    """)
//: Part 2
let daysInMonth = ["Jan": 31, "Feb": 28, "Mar": 31, "Apr": 30,
                   "May": 31, "Jun": 30, "Jul": 31, "Aug": 31,
                   "Sep": 30, "Oct": 31, "Nov": 30, "Dec": 31,]

for (month, days) in daysInMonth {
    print("\(days) days in month \(month)")
}

for month in daysInMonth.keys {
    print("\(month): \(daysInMonth[month]!) days")
}
print("---------------------------------")
//: Part 3
let cellLetter: [String] = ["a", "b", "c", "d", "e", "f", "g", "h"]

let cellNumber = Array(1...cellLetter.count)

var chessCells = [String: Bool]()

for (letter, value) in cellLetter.enumerated() {
    
    for number in cellNumber {
        
        if ((letter + number) % 2 == 0) {
    
            chessCells[value + String(number)] = true
            
        } else {
            
            chessCells[value + String(number)] = false
        }
    }
}
print(chessCells)
print("Count of cells: \(chessCells.count)")

