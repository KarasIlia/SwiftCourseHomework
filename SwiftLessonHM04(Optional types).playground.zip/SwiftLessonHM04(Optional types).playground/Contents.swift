//:Swift Lesson 4 - Homework
//:Part 1
let (string1, string2, string3, string4, string5) = ("He110!", "1.0", "1", "Hey, 666!", "1")

var sum = 0

if Int(string1) != nil {
    sum += Int(string1)!  // Forced unwrapping
}

if Int(string2) != nil {
    sum += Int(string2)!  // Forced unwrapping
}

if let number3 = Int(string3) { // Optional binding
    sum += number3
}

if let number4 = Int(string4) { // Optional binding
    sum += number4
}

if Int(string5) != nil {
    sum += Int(string5)! // Forced unwrapping
}

print("Sum of integer numbers = \(sum)")
//:Part 2
let serverInfo = (statusCode: 404, message: "Status code in range 200...300", errorMessage: "Error: status code out of range 200...300")

if (serverInfo.statusCode > 200 && serverInfo.statusCode < 300) {
    
    print(serverInfo.message)
    
} else {
    
    print(serverInfo.errorMessage)
}


let serverMessage: (message: String?, errorMessage: String?) = (nil, "!!!Wrong type of message!!!")

if let message = serverMessage.message {
    
    print(message)
    
} else if let errorMessage = serverMessage.errorMessage {
    
    print(errorMessage)
    
} else {
    
    print("Wrong data")
}
//:Part 3
var student1: (name: String?, carNumber: String?, testResult: Int?)
var student2: (name: String?, carNumber: String?, testResult: Int?)
var student3: (name: String?, carNumber: String?, testResult: Int?)
var student4: (name: String?, carNumber: String?, testResult: Int?)
var student5: (name: String?, carNumber: String?, testResult: Int?)

student1.name = "Dang"
student2.name = "Maria"
student3.name = "Stanislav"
student4.name = "Jack"
student5.name = "Daria"

student1.carNumber = "о666са"
student2.carNumber = "к159вх"
student5.carNumber = "None of your buisness"

student1.testResult = 0
student3.testResult = 4
student5.testResult = 5

print("-----------------------------------------------------------")
print("Student name: \(student1.name!)")

if let carNumber = student1.carNumber {
    
    print("Number of \(student1.name!)'s car = \(carNumber)")
    
} else {
    
    print("Student \(student1.name!) has no car")
}

if let testResult = student1.testResult {
    
    print("Student \(student1.name!)'s score for the last test = \(testResult)")
    
} else {
    
    print("Student \(student1.name!) skipped the last test")
}

print("-----------------------------------------------------------")


print("Student name: \(student2.name!)")

if student2.carNumber != nil {
    
    print("Number of \(student2.name!)'s car = \(student2.carNumber!)")
    
} else {
    
    print("Student \(student2.name!) has no car")
}

if let testResult = student2.testResult {
    
    print("Student \(student2.name!)'s score for the last test = \(testResult)")
    
} else {
    
    print("Student \(student2.name!) skipped the last test")
}

print("-----------------------------------------------------------")


print("Student name: \(student3.name!)")

if let carNumber = student3.carNumber {
    
    print("Number of \(student3.name!)'s car = \(carNumber)")
    
} else {
    
    print("Student \(student3.name!) has no car")
}

if student3.testResult != nil {
    
    print("Student \(student3.name!)'s score for the last test = \(student3.testResult!)")
    
} else {
    
    print("Student \(student3.name!) skipped the last test")
}

print("-----------------------------------------------------------")


print("Student name: \(student4.name!)")

if student4.carNumber != nil{
    
    print("Number of \(student4.name!)'s car = \(student4.carNumber!)")
    
} else {
    
    print("Student \(student4.name!) has no car")
}

if student4.testResult != nil{
    
    print("Student \(student4.name!)'s score for the last test = \(student4.testResult!)")
    
} else {
    
    print("Student \(student4.name!) skipped the last test")
}

print("-----------------------------------------------------------")


print("Student name: \(student5.name!)")

if let carNumber = student5.carNumber {
    
    print("Number of \(student5.name!)'s car = \(carNumber)")
    
} else {
    
    print("Student \(student5.name!) has no car")
}

if let testResult = student5.testResult {
    
    print("Student \(student5.name!)'s score for the last test = \(testResult)")
    
} else {
    
    print("Student \(student5.name!) skipped the last test")
}

print("-----------------------------------------------------------")
//:Tne End
