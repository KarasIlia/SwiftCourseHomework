//:Swift Lesson 06 | Homework
//: Part 1
import Foundation

var (string1, string2, string3, string4, string5) = ("He110!", "2", "4", "Hey666!", "5")
var sum = 0

sum += Int(string1) ?? 0
sum += Int(string2) ?? 0
sum += Int(string3) ?? 0
sum += Int(string4) ?? 0
sum += Int(string5) ?? 0

let str1 = "\((Int(string1) != nil) ? string1 : "nil")"
let str2 = "\((Int(string2) != nil) ? string2 : "nil")"
let str3 = "\((Int(string3) != nil) ? string3 : "nil")"
let str4 = "\((Int(string4) != nil) ? string4 : "nil")"
let str5 = "\((Int(string5) != nil) ? string5 : "nil")"
let str6 = "\(sum)"

let interpStr = "\(str1) + \(str2) + \(str3) + \(str4) + \(str5) = \(sum)" // Interpolation
let concontStr = str1 + " + " + str2 + " + " + str3 + " + " + str4 + " + " + str5 + " = " + str6 // Contonation

print(interpStr)
print(concontStr)
//:Part 2
let symbString = "\u{231A}\u{0488} \u{2620} \u{2699} \u{2615} \u{039E}\u{0489}"

print(symbString)

print("Counting the number of characters in string using the swift method = \(symbString.count)")
print("Counting the number of characters in string using the ObjC method = \((symbString as NSString).length)")
//:Part 3
let alphabet = "abcdefghijklmnopqrstuvwxyz"

var index = 0;

for i in alphabet {
    
    if i == "q" {
        
        print("Character index in string = \(index)")
    }
    
    index += 1
}
