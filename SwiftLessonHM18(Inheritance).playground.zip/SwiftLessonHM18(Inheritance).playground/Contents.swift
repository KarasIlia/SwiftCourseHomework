//: Swift Lesson 18 | Homework
import UIKit

print("---------------TASK I---------------")
class Artist {
    var firstName: String
    var lastName: String
    
    var fullName: String {
        get {
            return firstName + " " + lastName
        }
    }
    
    static var artists = [Artist]()
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
        Artist.artists.append(self)
    }
    
    func performance() {
        print("Artist performance")
    }
}

class Singer: Artist {
    override func performance() {
        print(fullName + " sings")
    }
}

class Dancer: Artist {
    override func performance() {
        print(fullName + " dancing")
    }
}

class Art: Artist {
    override var fullName: String {
        return self.firstName + " di ser Piero " + self.lastName + " the Great"
    }
    
    override func performance() {
        print(fullName + " draws" + "... and also I'm scientist, engineer, architect, anatomist." )
    }
}

let singer = Singer(firstName: "Bob", lastName: "Dylan")
let dancer = Dancer(firstName: "Michael", lastName: "Jackson")
let painter = Art(firstName: "Leonardo", lastName: "da Vinci")

for artist in Artist.artists {
    artist.performance()
}

print("---------------TASK II-----------------")

class Vehicle {
    
    static var vehiclesArray = [Vehicle]()
    
    var velocity: Double {
        get {
            return 0 // kph
        }
    }
    
    var capacity: Double {
        get {
            return 0 // people
        }
    }
    
    var cost: Double { // 1 carrying cost
        get {
            return 0 // rub
        }
    }
    
    func timeAndCost(distance: Double, passengers: Double) -> String {
        
        let shipments = (passengers / capacity).rounded(.up)
        let fullPrice = shipments * cost
        let time = (distance / velocity) * shipments

        return "\(fullPrice) RUB needed to carrying \(Int(passengers)) passengers over a distance \(distance) km. It will take \(Double(round(100*time)/100)) hours and \(Int(shipments)) shipment(s)"
    }
    
    init() {
        Vehicle.vehiclesArray.append(self)
    }
}

class Aircraft: Vehicle {
    
    override var velocity: Double {
        return 900
    }
    
    override var capacity: Double {
        return 120
    }
    
    override var cost: Double {
        return 600000
    }
    
    override func timeAndCost(distance: Double, passengers: Double) -> String {
        return super.timeAndCost(distance: distance, passengers: passengers) + " using aircraft."
    }
}

class Ship: Vehicle {
    
    override var velocity: Double {
        return 35
    }
    
    override var capacity: Double {
        return 2500
    }
    
    override var cost: Double {
        return 1250000
    }
    
    override func timeAndCost(distance: Double, passengers: Double) -> String {
        return super.timeAndCost(distance: distance, passengers: passengers) + " using ship."
    }
}

class Car: Vehicle {
    
    override var velocity: Double {
        return 120
    }
    
    override var capacity: Double {
        return 4
    }
    
    override var cost: Double {
        return 1500
    }
    
    override func timeAndCost(distance: Double, passengers: Double) -> String {
        return super.timeAndCost(distance: distance, passengers: passengers) + " using car."
    }
}

class Train: Vehicle {
    
    override var velocity: Double {
        return 125
    }
    
    override var capacity: Double {
        return 1000
    }
    
    override var cost: Double {
        return 2000000
    }
    
    override func timeAndCost(distance: Double, passengers: Double) -> String {
        return super.timeAndCost(distance: distance, passengers: passengers) + " using train."
    }
}

func counting(d: Double, p: Double) {
    
    print("COUNTING START")
    
    for vehicle in Vehicle.vehiclesArray {
        print(vehicle.timeAndCost(distance: d, passengers: p))
    }
}

let airBus = Aircraft()
let ship = Ship()
let car = Car()
let train = Train()

var distance: Double = 962
var passengers: Double = 100

counting(d: distance, p: passengers)

passengers = 100000
counting(d: distance, p: passengers)

print("----------------TASK III-----------------")

class LivingBeing {
    static var itsAlive = [LivingBeing]()
    
    init() {
        LivingBeing.itsAlive.append(self)
    }
}

class Animal: LivingBeing {
    static var animals = [Animal]()
    
    override init() {
        super.init()
        Animal.animals.append(self)
    }
}

class Reptile: Animal {
    static var reptiles = [Reptile]()
    
    override init() {
        super.init()
        Reptile.reptiles.append(self)
    }
}

class Quadruped: Animal {
    static var quadrupeds = [Quadruped]()
    
    override init() {
        super.init()
        Quadruped.quadrupeds.append(self)
    }
}


class Human: LivingBeing {
}

class Crocodile: Reptile {
}

class Ape: Quadruped {
}

class Dog: Quadruped {
}

class Giraffe: Quadruped {
}

var human1 = Human()
var croc1 = Crocodile()
var croc2 = Crocodile()
var ape = Ape()
var monkey = Ape()
var dog1 = Dog()
var giraffe1 = Giraffe()

LivingBeing.itsAlive.count
Animal.animals.count
Reptile.reptiles.count
Quadruped.quadrupeds.count
