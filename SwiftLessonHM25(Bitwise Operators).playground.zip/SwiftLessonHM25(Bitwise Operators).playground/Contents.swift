//: Swift Lesson 25 | Bitwise operators | Homework
//: Part 1
print("----------TASK I-----------")

extension UInt8 {
    
    func binary() -> String {
        
        var result = ""
        for i in 0..<8 {
            let mask = 1 << i
            let set = Int(self) & mask != 0
            result = (set ? "1" : "0") + result
        }
        return result
    }
}

enum CheckList: UInt8 {
    case bread =    0b00000001
    case chicken =  0b00000010
    case apples =   0b00000100
    case pears =    0b00001000
}

extension CheckList {
    func write(mask: inout UInt8) {
        mask = (mask & self.rawValue)
    }
    
    func read(mask: UInt8) {
        (mask & self.rawValue) > 0 ? print("\(self) is in the bag") : print("\(self) is not in the bag")
    }
}

var bag: UInt8 = 0b00001001

CheckList.bread.read(mask: bag)
CheckList.chicken.read(mask: bag)

//: Part 2
print("----------TASK II-----------")

var sin: UInt8 = 0b00001000

var i = -1
var j = 1

while j <= 30 {

    print(sin.binary())
    
    sin <<= i
    
    if sin == 128 {
        i = -1
    } else if sin == 1 {
        i = 1
    }
    
    j += 1
}
//: Part 3
print("----------TASK III-----------")

var cell: UInt64 = 1
let desk: UInt64 = 0b10101010_01010101_10101010_01010101_10101010_01010101_10101010_01010101

let dict = ["a":0, "b":1, "c":2, "d":3, "e":4, "f":5, "g":6, "h":7]

func printColorOfCell (_ column: String, _ row: Int) {
    
    if !dict.keys.contains(column.lowercased()) || !(1...8).contains(row) {
        print("Wrong cell (\(column)\(row))")
    } else if (desk & cell << (dict[column]! + ((row - 1) * 8))) == 0 {
        print("\(column)\(row) color: white")
    } else {
        print("\(column)\(row) color: black")
    }
}

printColorOfCell("h", 8)
printColorOfCell("a", 1)
printColorOfCell("a", 2)
printColorOfCell("f", 5)
printColorOfCell("f", 6)
printColorOfCell("h", 1)
printColorOfCell("c", 8)

printColorOfCell("y", 1)
printColorOfCell("a", 10)
